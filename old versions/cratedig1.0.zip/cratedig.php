<?php
/**
 * Plugin Name: CrateDig
 * Description: Publish vinyl listening history from CrateDig to your WordPress site.
 * Version:     1.0.0
 * Requires at least: 5.6
 * Author:      CrateDig
 */

defined( 'ABSPATH' ) || exit;

// ── CUSTOM POST TYPE ─────────────────────────────────────────────────────────

add_action( 'init', function () {

    register_post_type( 'cratedig_pick', [
        'labels'       => [
            'name'               => 'Listening Picks',
            'singular_name'      => 'Listening Pick',
            'add_new_item'       => 'Add New Pick',
            'edit_item'          => 'Edit Pick',
            'view_item'          => 'View Pick',
            'search_items'       => 'Search Picks',
            'not_found'          => 'No picks found.',
            'not_found_in_trash' => 'No picks found in Trash.',
        ],
        'public'              => false,
        'show_ui'             => true,
        'show_in_rest'        => true,
        'show_in_nav_menus'   => false,
        'supports'            => [ 'title', 'custom-fields' ],
        'menu_icon'           => 'dashicons-format-audio',
        'menu_position'       => 30,
    ] );

    // String meta fields
    foreach ( [ 'artist', 'title', 'year', 'label', 'country', 'artwork_url', 'pick_date', 'note', 'source', 'cratedig_id' ] as $field ) {
        register_post_meta( 'cratedig_pick', '_cratedig_' . $field, [
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => 'string',
            'auth_callback' => '__return_true',
        ] );
    }

    // Array meta fields
    foreach ( [ 'genres', 'styles' ] as $field ) {
        register_post_meta( 'cratedig_pick', '_cratedig_' . $field, [
            'show_in_rest'  => [
                'schema' => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ],
            ],
            'single'        => true,
            'type'          => 'array',
            'auth_callback' => '__return_true',
        ] );
    }
} );

// ── REST API ─────────────────────────────────────────────────────────────────

add_action( 'rest_api_init', function () {

    register_rest_route( 'cratedig/v1', '/entries', [
        [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => 'cratedig_list_entries',
            'permission_callback' => fn() => current_user_can( 'publish_posts' ),
        ],
        [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'cratedig_create_entry',
            'permission_callback' => fn() => current_user_can( 'publish_posts' ),
        ],
    ] );

    register_rest_route( 'cratedig/v1', '/entries/(?P<id>\d+)', [
        [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => 'cratedig_delete_entry',
            'permission_callback' => fn() => current_user_can( 'delete_posts' ),
            'args'                => [ 'id' => [ 'required' => true, 'type' => 'integer' ] ],
        ],
    ] );
} );

/**
 * GET /wp-json/cratedig/v1/entries
 * Returns all published picks ordered by pick date descending.
 * Used by CrateDig for connection testing and future sync.
 */
function cratedig_list_entries( WP_REST_Request $req ): WP_REST_Response {

    $posts = get_posts( [
        'post_type'      => 'cratedig_pick',
        'post_status'    => 'publish',
        'numberposts'    => 500,
        'orderby'        => 'meta_value',
        'meta_key'       => '_cratedig_pick_date',
        'order'          => 'DESC',
    ] );

    $entries = array_map( fn( $p ) => [
        'id'          => $p->ID,
        'artist'      => get_post_meta( $p->ID, '_cratedig_artist',      true ),
        'title'       => get_post_meta( $p->ID, '_cratedig_title',       true ),
        'year'        => get_post_meta( $p->ID, '_cratedig_year',        true ),
        'genres'      => (array) ( get_post_meta( $p->ID, '_cratedig_genres', true ) ?: [] ),
        'styles'      => (array) ( get_post_meta( $p->ID, '_cratedig_styles', true ) ?: [] ),
        'label'       => get_post_meta( $p->ID, '_cratedig_label',       true ),
        'country'     => get_post_meta( $p->ID, '_cratedig_country',     true ),
        'artwork_url' => get_post_meta( $p->ID, '_cratedig_artwork_url', true ),
        'pick_date'   => get_post_meta( $p->ID, '_cratedig_pick_date',   true ),
        'note'        => get_post_meta( $p->ID, '_cratedig_note',        true ),
        'source'      => get_post_meta( $p->ID, '_cratedig_source',      true ),
        'cratedig_id' => get_post_meta( $p->ID, '_cratedig_cratedig_id', true ),
    ], $posts );

    return new WP_REST_Response( $entries, 200 );
}

/**
 * POST /wp-json/cratedig/v1/entries
 * Creates a new pick entry. If an entry with the same cratedig_id already
 * exists the existing post ID is returned (idempotent).
 */
function cratedig_create_entry( WP_REST_Request $req ): WP_REST_Response|WP_Error {

    $data = $req->get_json_params();

    // Idempotency: same cratedig_id → return existing post
    $cratedig_id = sanitize_text_field( $data['cratedig_id'] ?? '' );
    if ( $cratedig_id ) {
        $existing = get_posts( [
            'post_type'      => 'cratedig_pick',
            'post_status'    => 'publish',
            'numberposts'    => 1,
            'meta_key'       => '_cratedig_cratedig_id',
            'meta_value'     => $cratedig_id,
        ] );
        if ( $existing ) {
            return new WP_REST_Response( [ 'id' => $existing[0]->ID ], 200 );
        }
    }

    $artist = sanitize_text_field( $data['artist'] ?? '' );
    $title  = sanitize_text_field( $data['title']  ?? '' );
    $year   = sanitize_text_field( $data['year']   ?? '' );

    $post_id = wp_insert_post( [
        'post_type'   => 'cratedig_pick',
        'post_status' => 'publish',
        'post_title'  => trim( $artist . ' — ' . $title . ( $year ? " ($year)" : '' ) ),
    ] );

    if ( is_wp_error( $post_id ) ) {
        return $post_id;
    }

    foreach ( [ 'artist', 'title', 'year', 'label', 'country', 'artwork_url', 'pick_date', 'note', 'source', 'cratedig_id' ] as $field ) {
        if ( isset( $data[ $field ] ) ) {
            update_post_meta( $post_id, '_cratedig_' . $field, sanitize_text_field( (string) $data[ $field ] ) );
        }
    }

    foreach ( [ 'genres', 'styles' ] as $field ) {
        if ( isset( $data[ $field ] ) && is_array( $data[ $field ] ) ) {
            update_post_meta( $post_id, '_cratedig_' . $field, array_map( 'sanitize_text_field', $data[ $field ] ) );
        }
    }

    return new WP_REST_Response( [ 'id' => $post_id ], 201 );
}

/**
 * DELETE /wp-json/cratedig/v1/entries/{id}
 * Permanently removes a pick by its WordPress post ID.
 */
function cratedig_delete_entry( WP_REST_Request $req ): WP_REST_Response|WP_Error {

    $id   = (int) $req->get_param( 'id' );
    $post = get_post( $id );

    if ( ! $post || $post->post_type !== 'cratedig_pick' ) {
        return new WP_Error( 'not_found', 'Entry not found.', [ 'status' => 404 ] );
    }

    $result = wp_delete_post( $id, true );

    return $result
        ? new WP_REST_Response( [ 'deleted' => true ], 200 )
        : new WP_Error( 'delete_failed', 'Could not delete entry.', [ 'status' => 500 ] );
}

// ── SHORTCODE [cratedig_history] ─────────────────────────────────────────────

add_shortcode( 'cratedig_history', function ( $atts ) {

    $atts = shortcode_atts( [
        'limit'  => 100,
        'source' => '',
        'year'   => '',      // e.g. year=2025  → only picks from that year
        'order'  => 'DESC',  // ASC or DESC by pick date
        'offset' => 0,       // skip first N results (for pagination)
    ], $atts );

    $meta_query = [ 'relation' => 'AND' ];

    if ( in_array( $atts['source'], [ 'daily', 'user' ], true ) ) {
        $meta_query[] = [ 'key' => '_cratedig_source', 'value' => $atts['source'] ];
    }

    // Year filter: match pick_date values that start with the given year
    $year = preg_replace( '/\D/', '', $atts['year'] );
    if ( strlen( $year ) === 4 ) {
        $meta_query[] = [
            'key'     => '_cratedig_pick_date',
            'value'   => $year,
            'compare' => 'LIKE',
        ];
    }

    $order = strtoupper( $atts['order'] ) === 'ASC' ? 'ASC' : 'DESC';

    $posts = get_posts( [
        'post_type'      => 'cratedig_pick',
        'post_status'    => 'publish',
        'numberposts'    => (int) $atts['limit'],
        'offset'         => max( 0, (int) $atts['offset'] ),
        'orderby'        => 'meta_value',
        'meta_key'       => '_cratedig_pick_date',
        'order'          => $order,
        'meta_query'     => count( $meta_query ) > 1 ? $meta_query : '',
    ] );

    if ( ! $posts ) {
        return '<p class="cratedig-empty" style="color:#999;font-style:italic;">No listening history published yet.</p>';
    }

    ob_start(); ?>
    <style>
      .cratedig-history { font-family: system-ui, -apple-system, sans-serif; }

      /* ── Row ── */
      .cratedig-pick {
        display: flex;
        flex-wrap: wrap;          /* lets the note column drop below on narrow screens */
        gap: 18px;
        padding: 20px 0;
        border-bottom: 1px solid #e8e8e8;
        align-items: flex-start;
      }
      .cratedig-pick:last-child { border-bottom: none; }

      /* ── Artwork ── */
      .cratedig-art {
        flex-shrink: 0;
        width: 96px; height: 96px;
        border-radius: 8px;
        overflow: hidden;
        background: #f2f2f2;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .cratedig-art img { width:100%; height:100%; object-fit:cover; display:block; }
      .cratedig-art-placeholder { font-size: 36px; color: #ccc; }

      /* ── Info column ── */
      .cratedig-info { flex: 1; min-width: 0; }
      .cratedig-artist { font-weight: 700; font-size: 1.05rem; margin-bottom: 3px; }
      .cratedig-title {
        font-style: italic;
        color: #777;
        font-size: 0.95rem;
        margin-bottom: 8px;
        /* allow wrapping — long titles were silently clipped on mobile */
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .cratedig-tags { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 6px; }
      .cratedig-tag {
        font-size: 0.72rem;
        background: #f0f0f0;
        padding: 3px 9px;
        border-radius: 10px;
        color: #555;
        text-transform: uppercase;
        letter-spacing: .05em;
      }
      .cratedig-tag.year { background: #fff3e0; color: #d4830a; }
      .cratedig-sub       { font-size: 0.78rem; color: #999; margin-bottom: 5px; }
      .cratedig-picked-on { font-size: 0.78rem; color: #999; margin-bottom: 5px; }
      .cratedig-source {
        display: inline-block;
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: .08em;
        padding: 3px 10px;
        border-radius: 10px;
      }
      .cratedig-source.daily { color: #c8922a; background: rgba(200,146,42,.1); }
      .cratedig-source.user  { color: #4a8c5c; background: rgba(74,140,92,.12); }

      /* ── Note column (desktop: right-side panel) ── */
      .cratedig-note-col {
        flex-shrink: 0;
        width: 210px;
        font-style: italic;
        color: #777;
        font-size: 0.9rem;
        line-height: 1.6;
        padding-left: 18px;
        border-left: 2px solid #efefef;
        align-self: center;
      }

      /* ── Mobile ── */
      @media (max-width: 640px) {
        .cratedig-art { width: 80px; height: 80px; }
        .cratedig-note-col {
          width: 100%;
          border-left: none;
          padding-left: 0;
          padding-top: 10px;
          border-top: 1px solid #efefef;
          margin-top: 2px;
        }
      }

      /* ── Very small screens ── */
      @media (max-width: 400px) {
        .cratedig-pick { gap: 12px; }
        .cratedig-art { width: 68px; height: 68px; }
        .cratedig-artist { font-size: 0.98rem; }
        .cratedig-title  { font-size: 0.88rem; }
      }
    </style>
    <div class="cratedig-history">
    <?php foreach ( $posts as $p ) :
        $artist      = get_post_meta( $p->ID, '_cratedig_artist',      true );
        $title       = get_post_meta( $p->ID, '_cratedig_title',       true );
        $year        = get_post_meta( $p->ID, '_cratedig_year',        true );
        $label       = get_post_meta( $p->ID, '_cratedig_label',       true );
        $country     = get_post_meta( $p->ID, '_cratedig_country',     true );
        $artwork_url = get_post_meta( $p->ID, '_cratedig_artwork_url', true );
        $pick_date   = get_post_meta( $p->ID, '_cratedig_pick_date',   true );
        $note        = get_post_meta( $p->ID, '_cratedig_note',        true );
        $source      = get_post_meta( $p->ID, '_cratedig_source',      true ) ?: 'daily';
        $genres      = (array) ( get_post_meta( $p->ID, '_cratedig_genres', true ) ?: [] );
        $styles      = (array) ( get_post_meta( $p->ID, '_cratedig_styles', true ) ?: [] );
        $tags        = array_slice( array_merge( $genres, $styles ), 0, 4 );
        // Strip milliseconds (.000) before strtotime — JS ISO strings include them,
        // but PHP's strtotime returns false if they're present.
        $ts          = $pick_date ? preg_replace( '/\.\d+/', '', $pick_date ) : '';
        $date_fmt    = $ts ? wp_date( 'M j, Y', strtotime( $ts ) ) : '';
        $sub_parts   = array_filter( [ $label, $country ] );
        $source_label = $source === 'daily' ? '🎵 Daily Pick' : '♥ My Pick';
    ?>
      <div class="cratedig-pick">
        <div class="cratedig-art">
          <?php if ( $artwork_url ) : ?>
            <img src="<?php echo esc_url( $artwork_url ); ?>" alt="<?php echo esc_attr( "$artist – $title" ); ?>" loading="lazy">
          <?php else : ?>
            <span class="cratedig-art-placeholder">♫</span>
          <?php endif; ?>
        </div>
        <div class="cratedig-info">
          <div class="cratedig-artist"><?php echo esc_html( $artist ); ?></div>
          <div class="cratedig-title"><?php echo esc_html( $title ); ?></div>
          <div class="cratedig-tags">
            <?php if ( $year ) : ?><span class="cratedig-tag year"><?php echo esc_html( $year ); ?></span><?php endif; ?>
            <?php foreach ( $tags as $tag ) : ?><span class="cratedig-tag"><?php echo esc_html( $tag ); ?></span><?php endforeach; ?>
          </div>
          <?php if ( $sub_parts ) : ?>
            <div class="cratedig-sub"><?php echo esc_html( implode( ' · ', $sub_parts ) ); ?></div>
          <?php endif; ?>
          <?php if ( $date_fmt ) : ?>
            <div class="cratedig-picked-on">Picked on: <?php echo esc_html( $date_fmt ); ?></div>
          <?php endif; ?>
          <span class="cratedig-source <?php echo esc_attr( $source ); ?>"><?php echo esc_html( $source_label ); ?></span>
        </div>
        <?php if ( $note ) : ?>
        <div class="cratedig-note-col"><?php echo esc_html( $note ); ?></div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
} );
